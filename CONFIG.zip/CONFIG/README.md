# oh-my-awesomewm-dots
 warm & comfy awm+widgets+themes rice

 

 * Default Theme - Gruvbox
 <img src="/assets/default-preview.png">
 
 * Gtk
 <img src="/assets/gtk3.png">
 
 * Mira
 <img src="/assets/mira.png">
 
 * Steamburn
 <img src="/assets/steamburn2.png">
 
